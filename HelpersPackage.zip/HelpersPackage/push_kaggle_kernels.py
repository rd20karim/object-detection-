
from google.colab import files
files.upload()

"""SET KAGGLE DIRECTORY"""

!pip install -q kaggle
!mkdir -p ~/.kaggle
!cp kaggle.json ~/.kaggle/
!ls ~/.kaggle
# we need to set permissions 
!chmod 600 /root/.kaggle/kaggle.json

"""CHECK THE KAGGLE API IS RUNNING"""

#!kaggle kernels list --user "rd20karim" --sort-by dateRun

#!kaggle kernels list -h

# Commented out IPython magic to ensure Python compatibility.
# %cd /content/drive/My Drive/kaggle/kernel_1

# user --name/kernel-name you can copy paste from your kernel list
#!kaggle kernels pull rd20karim/kernel-colab-1 -m
print(all kernels was pushed to kaggle )
!kaggle kernels push



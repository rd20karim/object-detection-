# -*- coding: utf-8 -*-
"""
Created on Mon Apr 13 16:11:36 2020

@author: R.karim

"""
from skimage.io import imread
from skimage.transform import resize
import numpy as np 
import tensorflow
import matplotlib.pyplot as plt
import os
# Here, `x_set` is list of path to the images
# and `y_set` are the associated classes.

class SAR_Sequence(tensorflow.keras.utils.Sequence):
  
    def __init__(self, directory, batch_size =32,shuffle = True,phase=False,normalization=True,rgb=False,square_img_length=88):
        self.directory = directory
        self.shuffle = shuffle
        self.x, self.y = self.get_random_path()
        self.batch_size = batch_size
        self.phase = phase
        self.norm = normalization
        self.rgb = rgb
        self.h =square_img_length
        

    def __len__(self):
        return int(np.ceil(len(self.x) / float(self.batch_size)))

    def __getitem__(self, idx):
        batch_x = self.x[idx * self.batch_size:(idx + 1) * self.batch_size]
        batch_y = self.y[idx * self.batch_size:(idx + 1) * self.batch_size]
      
        if not self.phase and not self.rgb:
            return (np.array([resize(imread(file_name),(h,h,1))for file_name in batch_x]) , np.array(batch_y))
        elif not self.phase:
            gray_to_rgb = lambda img_array:np.stack([img_array,img_array,img_array],axis=2)
            return (np.array([resize(gray_to_rgb(imread(file_name)),(self.h,self.h,3))for file_name in batch_x]) , np.array(batch_y))
        
        else: 
              batch_list = []
              for file_name in batch_x:
                    im = np.zeros((h,h,3))
                    mat_batch= self.get_complexs_image(imread(file_name))
                    for k in range(3):
                            im[:,:,k] = resize(mat_batch[k],(h,h)) # resize each of the 3 matrix real,imagi,phase

                    batch_list.append(im) # list of 3D matrix of size batch  

              return np.array(batch_list) , np.array(batch_y)

    def get_complexs_image(self,image):
      if not self.phase:
        if self.norm:
          return norm(np.abs(image))
        else : 
          return np.abs(image)
      else:
        cimg = np.fft.fft2(image)
        ph_img = np.angle(cimg) # rad
        if self.norm:
          n_img = self.rescaling_01(image)
          return self.rescaling_01(n_img*np.cos(ph_img),n_img*np.sin(ph_img),ph_img)
        else :
          return image*np.cos(ph_img),image*np.sin(ph_img),ph_img
    
    def rescaling_01(self,*args):
      #return a table of 1 or 3 matrix (real,imagi,phase)

      nor = lambda mat : (mat/np.max(np.abs(mat)))+1. 
      if len(args) == 1:
        return nor(args[0])
      else:
        return nor(args[0]),nor(args[1]),nor(args[2])

    def get_path_files(self):
        x_set,y_set = [],[]
        # return a list of patchs and associate labels 
        self.name_classes = os.listdir(self.directory)
        self.classe_indices = {k:idx for idx,k in enumerate(self.name_classes)}
        self.num_classes    = len(self.name_classes)
        
        for i in range(self.num_classes):
          sub_dirc = self.name_classes[i]
          path_sub_dirc = os.path.join(self.directory,sub_dirc)
          x_set +=  [os.path.join(path_sub_dirc ,file_name) for file_name in os.listdir(path_sub_dirc)]
          y_set += [self.classe_indices[sub_dirc]]*len(os.listdir(path_sub_dirc))
        return x_set,y_set
        
    def get_random_path(self):         
      x_set,y_set = self.get_path_files()
      if self.shuffle:            
        per = np.random.permutation(len(x_set))
        x_set = [x_set[idx]  for idx in per ]
        y_set = [y_set[idx]  for idx in per ]
        return x_set,y_set 
      else :
        return x_set,y_set

